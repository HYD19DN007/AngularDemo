import { Component, OnInit } from '@angular/core';
import { User } from '../User';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  public topics=['Angular','React','Vue'];
  userModel=new User('Thu','Thu@gmail.com',3434343,'Angular','Morning',true);

  constructor() { }
  getData()
  {
    console.log(this.userModel.userName+ " "+ this.userModel.email);


  }
  getUserData(form:any)
  {
    console.log(form.userName+ " "+ form.email);

  }


  ngOnInit(): void {
  }

}
