export class User
{
    public userName:string="";
    public email:string="";
    public phone:string="";
    public topic:string="";
    public timepreference:string="";
    public transport:boolean=false;

   constructor(){
    this.topic="";
   }

}